import{u as s,j as e}from"./index-DzgntFnC.js";import{c as r}from"./createLucideIcon-CMjKDoEE.js";/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=r("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]);function c(){const{lang:t,setLang:a}=s();return e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(l,{className:"w-4 h-4 text-slate-500"}),e.jsx("button",{onClick:()=>a("fr"),className:`px-2 py-1 text-sm rounded transition-colors ${t==="fr"?"bg-emerald-600 text-white":"bg-slate-100 text-slate-600 hover:bg-slate-200"}`,children:"FR"}),e.jsx("button",{onClick:()=>a("ar"),className:`px-2 py-1 text-sm rounded transition-colors ${t==="ar"?"bg-emerald-600 text-white":"bg-slate-100 text-slate-600 hover:bg-slate-200"}`,children:"عربي"})]})}export{c as L};
