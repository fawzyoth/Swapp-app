import{c as o}from"./createLucideIcon-CMjKDoEE.js";/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=o("Play",[["polygon",{points:"5 3 19 12 5 21 5 3",key:"191637"}]]);export{c as P};
